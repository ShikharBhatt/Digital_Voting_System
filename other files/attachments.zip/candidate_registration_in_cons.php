<?php
//fire trigger
session_start();
$REG=$_SESSION['REGISTERED'];
if($REG==='Yes')
		{
			$con = mysqli_connect('localhost','root','6991');
			if(!$con) echo 'cannot connect';
			if(!mysqli_select_db($con,'dvs'))
				echo 'cannot connect';

				
				$check=$_SESSION['VOTER_ID'];
				$CONS_ID= $_SESSION['CONSM_ID'];
				$star="select * from candidate_table where VOTER_ID='$check'";
				
				
				$result=mysqli_query($con,$star); //successful execution of query;
				$row=mysqli_fetch_array($result);
				if($row['VOTER_ID']===$check)//always true
				{		
					$CAND_ID=$row['CAND_ID'];
					echo "<br><br>".$CAND_ID." ".$CONS_ID;
					
					$query="select count(*) as count_ ,CT_CONS_ID from cand_cons_table where CAND_ID='$CAND_ID'";
					$result1=mysqli_query($con,$query);
					$row1=mysqli_fetch_array($result1);
					if($row1['count_']<2 && ($row1['CT_CONS_ID']!== $CONS_ID ) || $row1['CT_CONS_ID']!=='')
					{
						$query="insert into cand_cons_table (CAND_ID,CT_CONS_ID)values('$CAND_ID','$CONS_ID')";
						if(mysqli_query($con,$query))
							echo "triggered";
						else
							echo "trigger failed";
					}
					else
						echo "you are trying to register for more than 2 constituencies or more than one time from the same constituency";
				}
				else
					echo "<h1>you identified</h1>";
				
		}		
		else echo"not registered";

					//header("refresh:4;candidate_registration_inter.php");
		header("refresh:4;ro_intermediate.php");
?>