	<?php
	session_start();
	if(!isset($_POST['VOTER_ID']))
	{
		header("refresh:1;url=candidate_registration_inter.php");
	}	
	
	$con = mysqli_connect('localhost','root','6991');
	if(!$con) echo 'cannot connect';
	if(!mysqli_select_db($con,'dvs'))
		echo 'cannot connect';

				$check=$_POST['VOTER_ID'];
				echo "checking for ".$check;
				$_SESSION['VOTER_ID']=$check;
				$star="select * from voter_table where VOTER_ID='$check'";
					
					$result=mysqli_query($con,$star); //successful execution of query;
					$row=mysqli_fetch_array($result);
					//echo "-------result -------".$result['0'];
					if($row['VOTER_ID']===$check)
					{		
						
						echo "in if..... ";
						$_SESSION['FNAME']=$row['FNAME'];
						$_SESSION['MNAME']=$row['MNAME'];
						$_SESSION['LNAME']=$row['LNAME'];
						//$_SESSION['PARTY_NAME']=$row['PARTY_NAME'];
						$_SESSION['TITLE']=$row['TITLE'];
						$_SESSION['EDU_LEVEL']=$row['EDU_LEVEL'];

						echo $_SESSION['FNAME'];
						echo $_SESSION['MNAME'];
						echo $_SESSION['LNAME'];
						//echo $_SESSION['PARTY_NAME'];
						echo $_SESSION['TITLE'];
						echo $_SESSION['EDU_LEVEL'];
						
												
						header("refresh:2;url=candidate_registration.php");
					}
				
				else
					{
						echo '<br>not found pls....!!';
						header("refresh:2;url=candidate_registration_inter.php");		
					
					}
			
			
		//}		

	?>

