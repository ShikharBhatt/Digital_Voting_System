
<?php
session_start();
/*if(!isset($_POST['VOTER_ID']))
{
	header("refresh:1;url=candidate_registration_inter.php");
}*/

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

	
	$RO_ID = $_SESSION['RO_ID'];
	$CONS_ID= $_SESSION['CONSM_ID'];
	$VOTER_ID = $_SESSION['VOTER_ID'];
	$FNAME= $_SESSION['FNAME'];
	$MNAME = $_SESSION['MNAME'];
	$LNAME = $_SESSION['LNAME'];
	$PARTY_NAME= $_POST['PARTY_NAME'];
	$WORK_EXP = $_POST['WORK_EXP'];
	$POL_EXP= $_POST['POL_EXP'];

	$ACHIEVEMENTS = $_POST['ACHIEVEMENTS'];
	
	$EDU_LEVEL= $_SESSION['EDU_LEVEL'];
	
											echo $RO_ID;echo "<br>";
											echo $CONS_ID;echo "<br>";
											echo $VOTER_ID;echo "<br>";
											echo $FNAME;echo "<br>";
											echo $MNAME;echo "<br>";
											echo $LNAME;echo "<br>";
											echo $PARTY_NAME;echo "<br>";
											echo $WORK_EXP;echo "<br>";
											echo $POL_EXP;echo "<br>";
											echo $ACHIEVEMENTS;echo "<br>";	
											echo $EDU_LEVEL;echo "<br>";
											
											
	//$query="insert into voter_table()values(11,'$name') ";
	//$CAND_ID='cad_'.mt_rand(010,100);
	/*$star="INSERT INTO candidate_table (VOTER_ID,PARTY_NAME,FNAME,MNAME,LNAME,EDU_LEVEL,WORK_EXP,POL_EXP,ACHIEVEMENTS)
	values ('$VOTER_ID','$PARTY_NAME','$FNAME','$MNAME','$LNAME','$EDU_LEVEL','$WORK_EXP','$POL_EXP','$ACHIEVEMENTS')";*/
	
	/*$star="INSERT INTO fake_table (VOTER_ID,PARTY_NAME,FNAME,MNAME,LNAME)
	values ('$VOTER_ID','$PARTY_NAME','$FNAME','$MNAME','$LNAME')";*/
	
/*	if(!mysqli_query($con,$star))
	{		
		echo 'not registered';
		
	}*/
//	else
//	{
		
		$file = $_FILES['PROP_AFF'];    //receive the posted file
		//echo  $_FILES['PRH']['name'];
		$name = $file['name'];
		echo $name;
		$fileext = explode('.',$name);
		$afileext= strtolower(end($fileext));
		
		$file1 = $_FILES['BUSS_AFF'];    //receive the posted file
		//echo  $_FILES['PRH']['name'];
		$name1 = $file1['name'];
		echo " ".$name1;
		$fileext1 = explode('.',$name1);
		$afileext1= strtolower(end($fileext1));
		
		$file2= $_FILES['CRIM_AFF'];    //receive the posted file
		//echo  $_FILES['PRH']['name'];
		$name2 = $file2['name'];
		echo " ".$name2;
		$fileext2 = explode('.',$name2);
		$afileext2= strtolower(end($fileext2));
		
		$allowed = array('pdf','jpg');

		if(in_array($afileext,$allowed) && in_array($afileext1,$allowed) && in_array($afileext2,$allowed))
		{	
			//if($file['error']===0)
			//$content = addslashes(file_get_contents($_FILES['PROP_AFF']['tmp_name']));
			//echo $content;
			$property = addslashes(file_get_contents($_FILES['PROP_AFF']['tmp_name']));
			$bussaff = addslashes(file_get_contents($_FILES['BUSS_AFF']['tmp_name']));
			$crime = addslashes(file_get_contents($_FILES['CRIM_AFF']['tmp_name']));

			$path = "C:/xamppp/htdocs/miniproject/uploads/" . uniqid('',true).".".$afileext; // moving property(aff)  to uploads folder 
			if (move_uploaded_file($file['tmp_name'], $path))
			{
				echo "<br>".$file['tmp_name'];
				echo "uploaded and moved";
				
			}
			//$content =$path;
			$star="INSERT INTO candidate_table (VOTER_ID,PARTY_NAME,FNAME,MNAME,LNAME,EDU_LEVEL,WORK_EXP,POL_EXP,ACHIEVEMENTS,PROP_AFF,BUSS_AFF,CRIM_AFF)
			values ('$VOTER_ID','$PARTY_NAME','$FNAME','$MNAME','$LNAME','$EDU_LEVEL','$WORK_EXP','$POL_EXP','$ACHIEVEMENTS','$property','$bussaff','$crime')";
		
					if(!mysqli_query($con,$star))
					{		
						echo '<br>already registered.....';
							$_SESSION['REGISTERED']="Yes";
							header("refresh:4;candidate_registration_in_cons.php");
					}
				
					else
					{
						echo "<br>registered";
						echo "<br>image fetched ......>";
						$_SESSION['REGISTERED']="Yes";
						header("refresh:4;candidate_registration_in_cons.php");
					}
		}
		
		else		
		{	echo "not expected file!!  not registered";
				header("refresh:4;candidate_registration.php");
		}
	//}		
//session_destroy();
	
//header("refresh:4;candidate_registration_inter.php");
?>

