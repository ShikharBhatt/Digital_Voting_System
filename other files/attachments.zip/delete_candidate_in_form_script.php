
<?php
session_start();
/*if(!isset($_POST['VOTER_ID']))
{
	header("refresh:1;url=candidate_registration_inter.php");
}*/
$check=$_SESSION['DEL_CANDIDATE_ID'];
$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

			$star="delete from candidate_table where CAND_ID='$check'";
		
					if(!mysqli_query($con,$star))
					{		
						echo '<br>could not delete.....';
								
					}
				
					else
					{
						echo "<br>record deleted ";						
					}
		
		
		header("refresh:4;delete_candidate.php");
?>

