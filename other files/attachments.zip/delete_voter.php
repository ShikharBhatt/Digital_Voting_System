<?php
	session_start();
	?>
	
	<html>
	<head>
	<link rel="stylesheet" type="text/css" href="form_style.css">
		</head>
	<div >
	<!--<button class="button button1"  onclick="ro_intermediate.php;">Back </button>-->
	<form action="fo_intermediate.php" method="post">
	<button class="button button1" >Back </button>
	</form>
	<form name="delete_voter_script" action="delete_voter_script.php" method="post">

		<tr><td><label style="position:absolute;top:44%;left:20%;" >Voter ID :</label> 
	        <td><input style="position:absolute;top:42%;left:30%;" type="tel" name="DEL_VOTER_ID" minlength="10" maxlength="10" />   
	        <br>
	<button class="button button1"  type="submit" name="SUB" style="position:absolute;top:40%;right:30%;" >CHECK</button>
	</form>
	</div>
	
	<body>
	</body>
	</html>