<html>
<body>

<?php
session_start();

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

	$check=$_SESSION['DEL_VOTER_ID'];

	$query="delete from voter_table where  VOTER_ID ='$check' ";
	
	if(!mysqli_query($con,$query))
	{
		echo "<h1>failed</h1>";
		//echo("Error description: " . mysqli_error($con));
	}
	else
	{ 
		echo "<h1> record deleted<h1>";
	//	header("refresh:5; url=update_voter.php");
		header("refresh:5; url=fo_intermediate.php");
	}
	//error_reporting(E_ALL);
?>
</html>
</body>
