<html>

<body>

<?php
session_start();
$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';
	
	$ID = $_POST['ID'];
	$PASS= $_POST['PASS'];
	//$query="insert into voter_table()values(11,'$name') ";
	
	$star="select * from fo_table where FO_ID= '$ID' and PASSWORD= '$PASS' ";
	if($result=mysqli_query($con,$star))
	{		
		$row=mysqli_fetch_array($result);
		if($row['FO_ID']== $ID && $row['PASSWORD']==$PASS)
		{
			echo "<h1> welcome fo!</h1>";
			echo "<br>".$row['FO_ID'];

			$_SESSION['FO_ID']=$row['FO_ID'];
			$_SESSION['FCONSM_ID']=$row['CONS_ID'];
			$_SESSION['VOTER_ID']=$row['VOTER_ID'];

			echo "<br>"."    ".$_SESSION['FO_ID'];
			echo "<br>"."    ".$_SESSION['FCONSM_ID'];
			echo "<br>"."    ".$_SESSION['VOTER_ID'];
			header("refresh:1;url=fo_intermediate.php");
		}
		else 
		{	echo "wrong password/username";
			header("refresh:2; url=modal_login.php");
		}
		
	}
	else
		{	echo "use correct identifier";
		//	header("refresh:2; url=vportalfo.htmll");
		}
?>