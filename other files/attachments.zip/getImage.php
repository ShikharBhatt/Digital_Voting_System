<?php

  $id = $_GET['id'];
  // do some validation here to ensure id is safe
$servername = "localhost";
$username = "root";
$password = 6991;
$dbname = "dvs";

// Create connection
$conn = new mysqli('localhost', 'root', 6991, 'dvs');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT PHOTO FROM voter_table WHERE VOTER_ID=$id";
$result = $conn->query($sql);


   $row = $result->fetch_assoc();
       // echo "bid: " . $row["bid"]. " - Name: " . $row["bname"]. "Color: " . $row["color"]. "<br>";
      
    $conn->close();   
  
  header("Content-type: image/jpg");
  echo $row['PHOTO'];
?>