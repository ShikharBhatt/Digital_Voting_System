
	<html>
	<head><?php
	session_start();


	?></head>
	<body>
	<?php


	$con = mysqli_connect('localhost','root','6991');
	if(!$con) echo 'cannot connect';
	if(!mysqli_select_db($con,'dvs'))
		echo 'cannot connect';

		
		$ID = $_POST['ID'];
		$PASS= $_POST['PASS'];

		//$query="insert into voter_table()values(11,'$name') ";
		
		$star="select * from ro_table where RO_ID= '$ID' and PASSWORD= '$PASS' ";
		if($result=mysqli_query($con,$star))//if query fails to execute
		{		
			$row=mysqli_fetch_array($result);
			if($row['RO_ID']== $ID && $row['PASSWORD']==$PASS)
			{
				echo "<h2>Welcome! <br> RO </h2>" ;

				echo " ".$row['RO_ID'];

				$_SESSION['RO_ID']=$row['RO_ID'];					//making RO_ID a session variable
				echo "<br> SESSION OF RO -- ".$_SESSION['RO_ID'];

				$_SESSION['CONSM_ID']=$row['CONSM_ID'];				//making CONSM_ID a session variable
				echo "<br> CONSM_ID -- ".$_SESSION['CONSM_ID'];
				
				$_SESSION['VOTER_ID']=$row['VOTER_ID'];				//making CONSM_ID a session variable
				echo "<br> VOTER_ID -- ".$_SESSION['VOTER_ID'];
				//$_SESSION['LOGIN']='Yes';
				header("refresh:1;url=ro_intermediate.php");
				
			}
			else 
			{	echo "wrong password/username";
				header("refresh:2; url=modal_login.html");
			}
			
		}
		else
			{	echo "use correct identifier";
			//	header("refresh:2; url=ro_login_page.html");
			}
		
			
		
			

	?>
	</html>
	</body>
