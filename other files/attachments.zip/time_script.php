<?php
session_start();

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

$VOTER_ID=$_SESSION['VOTER_ID'];

if($_POST['vote']=="NULL")
{
$star="insert into vote_table (VOTER_ID,CAND_ID) values ('$VOTER_ID',NULL)";

}
else
{
echo "<br><br>".$_POST['vote'];
$VOTED_FOR=$_POST['vote'];
$star="insert into vote_table (VOTER_ID,CAND_ID) values ('$VOTER_ID','$VOTED_FOR')";
}
if(mysqli_query($con,$star))	
	{
		
		echo "transferring your vote.......";
		//sleep(1);

		$status="select STATUS from voter_table where VOTER_ID='$VOTER_ID'";
		if($result=mysqli_query($con,$status))
		{
			$row=mysqli_fetch_array($result);
			if($row['STATUS']=='YES')
				{
				echo "<h2>you have successfully voted !<h2>";
				header("refresh:2;url=vportalvoter_final.php");
			    }
			else
				echo "problem in yes checking";
		}
		else
			echo "0 rows returned";

	}
else
	{ 
		echo "<br>error occurred while transferring your vote(voting twice) !<h2>";
		header("refresh:2;url=vportalvoter_final.php");
	//	echo ("error".mysql_error($con));
	}
?>