	<?php
	session_start();
	?>
	
	<html>
	<head>
	<link rel="stylesheet" type="text/css" href="form_style.css">
		</head>
	<div >
	<!--<button class="button button1"  onclick="ro_intermediate.php;">Back </button>-->
	<form action="ro_intermediate.php" method="post">
	<button class="button button1" style="margin-left: 0px;" >Back </button>
	</form>
	<form name="update_candidate_script.php" action="update_candidate_script.php" method="post">

		<tr><td><label style="position:absolute;top:44%;left:25%;" ><font size="5px">Candidate ID :</font></label> 
	        <td><input style="position:absolute;top:42%;left:40%;height:40px;"  type="number" name="UP_CANDIDATE_ID" minlength="10" maxlength="10" />   
	        <br>
	<button class="button button1"  type="submit" name="SUB" style="position:absolute;top:40%;right:20%;" >UPDATE</button>
	</form>
	</div>
	
	<body>
	</body>
	</html>

	

