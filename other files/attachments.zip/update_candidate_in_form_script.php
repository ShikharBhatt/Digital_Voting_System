
<?php
session_start();
/*if(!isset($_POST['VOTER_ID']))
{
	header("refresh:1;url=candidate_registration_inter.php");
}*/

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

	$check=$_SESSION['UP_CANDIDATE_ID'];
	$RO_ID = $_SESSION['RO_ID'];
	$CONS_ID= $_SESSION['CONSM_ID'];
	$VOTER_ID = $_SESSION['VOTER_ID'];
	$FNAME= $_POST['FNAME'];
	$MNAME = $_POST['MNAME'];
	$LNAME = $_POST['LNAME'];
	$PARTY_NAME= $_POST['PARTY_NAME'];
	$WORK_EXP = $_POST['WORK_EXP'];
	$POL_EXP= $_POST['POL_EXP'];

	$ACHIEVEMENTS = $_POST['ACHIEVEMENTS'];
	
	$EDU_LEVEL= $_POST['EDU_LEVEL'];
											echo $check;
											echo $_SESSION['UP_CANDIDATE_ID'];
											echo $RO_ID;echo "<br>";
											echo $CONS_ID;echo "<br>";
											echo $VOTER_ID;echo "<br>";
											echo $FNAME;echo "<br>";
											echo $MNAME;echo "<br>";
											echo $LNAME;echo "<br>";
											echo $PARTY_NAME;echo "<br>";
											echo $WORK_EXP;echo "<br>";
											echo $POL_EXP;echo "<br>";
											echo $ACHIEVEMENTS;echo "<br>";	
											echo $EDU_LEVEL;echo "<br>";
											
											
	//$query="insert into voter_table()values(11,'$name') ";
	//$CAND_ID='cad_'.mt_rand(010,100);
	/*$star="INSERT INTO candidate_table (VOTER_ID,PARTY_NAME,FNAME,MNAME,LNAME,EDU_LEVEL,WORK_EXP,POL_EXP,ACHIEVEMENTS)
	values ('$VOTER_ID','$PARTY_NAME','$FNAME','$MNAME','$LNAME','$EDU_LEVEL','$WORK_EXP','$POL_EXP','$ACHIEVEMENTS')";*/
	
	/*$star="INSERT INTO fake_table (VOTER_ID,PARTY_NAME,FNAME,MNAME,LNAME)
	values ('$VOTER_ID','$PARTY_NAME','$FNAME','$MNAME','$LNAME')";*/
	
/*	if(!mysqli_query($con,$star))
	{		
		echo 'not registered';
		
	}*/
//	else
//	{
		
		$file = $_FILES['PROP_AFF'];    //receive the posted file
		//echo  $_FILES['PRH']['name'];
		$name = $file['name'];
		echo $name;
		$fileext = explode('.',$name);
		$afileext= strtolower(end($fileext));
		
		$allowed = array('pdf','jpg');
		if(in_array($afileext,$allowed))
		{	
			//if($file['error']===0)
			//$content = addslashes(file_get_contents($_FILES['PROP_AFF']['tmp_name']));
			//echo $content;
			$path = "C:/xamppp/htdocs/miniproject/uploads/" . uniqid('',true).".".$afileext; // 5
			if (move_uploaded_file($file['tmp_name'], $path))
			{
				echo "<br>".$file['tmp_name'];
				echo "uploaded and moved";
				
			}
			$content =$path;
			$star=" update candidate_table  set 
			VOTER_ID='$VOTER_ID',PARTY_NAME='$PARTY_NAME',FNAME ='$FNAME',MNAME='$MNAME' ,LNAME='$LNAME', 
			EDU_LEVEL='$EDU_LEVEL', WORK_EXP='$WORK_EXP', POL_EXP='$POL_EXP', ACHIEVEMENTS='$ACHIEVEMENTS', PROP_AFF='$content' where CAND_ID='$check'";
		
					if(!mysqli_query($con,$star))
					{		
						echo '<br>could not update.....';
							
							header("refresh:4;update_candidate.php");
					}
				
					else
					{
						echo "<br>record updated";
						
						header("refresh:4;update_candidate.php");
					}
		}
		
		else		
		{	echo "not expected file!!  not registered";
			header("refresh:4;update_candidate_in_form.php");
		}
	//}		
//session_destroy();
	
//header("refresh:4;candidate_registration_inter.php");
?>

