	<?php
	session_start();
	?>
	
	<html>
	<head>
	<link rel="stylesheet" type="text/css" href="form_style.css">
		</head>
	<div >

	<form name="voter_updation" action="update_voter_script.php" method="post">
		<tr><td><label style="position:absolute;top:44%;left:20%;" >Voter ID :</label> 
	        <td><input style="position:absolute;top:42%;left:30%;" type="number" name="UP_VOTER_ID" minlength="10" maxlength="10" />   
	        <br>
	<button class="button button1"  type="submit" name="SUB" style="position:absolute;top:40%;right:30%;" >UPDATE</button>
	</form>
	</div>
	
	<body>
	</body>
	</html>

	

