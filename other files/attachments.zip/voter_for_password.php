	<?php
	session_start();

	if(isset($_POST['SUB']) && $_POST['G_VOTER_ID']!='')
	{
		//echo "<br>G_voter_id";
	//echo $_POST['G_VOTER_ID'];
	$_SESSION['G_VOTER_ID']=$_POST['G_VOTER_ID'];
	//echo "<br>".$_SESSION['G_VOTER_ID'];
	$con = mysqli_connect('localhost','root','6991');
	if(!$con) echo 'cannot connect';
	if(!mysqli_select_db($con,'dvs'))
		echo 'cannot connect';

				function random_password( $length = 8 ) {
   							 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_";
    						$password = substr( str_shuffle( $chars ), 0, $length );
    						return $password;
					}

				$check=$_POST['G_VOTER_ID'];
				$PASSWORD=random_password();
					$_SESSION['PASSWORD']=$PASSWORD;	
				$star="UPDATE voter_table SET PASSWORD='$PASSWORD' where VOTER_ID='$check'";
					

				//echo "<br><br><br>into main code";

					 //successful execution of query;
					mysqli_query($con,$star);
					if(mysqli_affected_rows($con)>0)
					//$rows=mysqli_num_rows($result);
					//if($rows>0)
					{							
						//echo '<br>YOUR PASSWORD: '.$PASSWORD;					
						header("refresh:0;url=voter_for_password_script.php");

					}
				
				else
					{
						echo '<script>alert("not found")</script>';
						//echo '<br>not found pls....!!';
						header("refresh:0;url=voter_for_password.php");		
					
					}
			
			
				
    
	}
	?>
	
	<html>
	<head>
	<link rel="stylesheet" type="text/css" href="form_style.css">
	<style>
	input[type=text],[type=tel],[type=number] {
    
    padding: 5px 10px;
    margin: 8px 0;
    display: inline-block;
    border: 2px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
    font-family: verdana;
    font-size: 12px;
   
    width:210px;
   }
	</style>
		</head>
	<div >

	<form name="voter_for_password"  method="post">
		<tr><td><label style="position:absolute;top:44%;left:20%;" >Voter ID :</label> 
	        <td><input style="position:absolute;top:42%;left:30%;" type="tel" name="G_VOTER_ID" minlength="10" maxlength="10" />   </tr>
	        <tr><label style="position:absolute;top:60%;left:20%;" >Password :</label> 
	        <input style="position:absolute;top:58%;left:30%;" type="text" disabled/></tr> 
	        <br>
	<button class="button button1"  type="submit" name="SUB" style="position:absolute;top:40%;right:30%;" >Generate</button>
	</form>
	</div>
	
	<body>
	</body>
	</html>



