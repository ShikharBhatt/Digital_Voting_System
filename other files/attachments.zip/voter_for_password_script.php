<?php
	
	session_start();

	/*if(!isset($_POST['G_VOTER_ID']) || trim($_POST['G_VOTER_ID'])== '')
	{
		header("refresh:0;url=voter_for_password.php");
		//	echo "is empty";
		
	}
	else
	{
*/
	//echo "<br>G_voter_id";
	//echo $_POST['G_VOTER_ID'];
	/*$_SESSION['G_VOTER_ID']=$_POST['G_VOTER_ID'];
	echo "<br>".$_SESSION['G_VOTER_ID'];
	$con = mysqli_connect('localhost','root','6991');
	if(!$con) echo 'cannot connect';
	if(!mysqli_select_db($con,'dvs'))
		echo 'cannot connect';
/*
				function random_password( $length = 8 ) {
   							 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_";
    						$password = substr( str_shuffle( $chars ), 0, $length );
    						return $password;
					}
				$PASSWORD=random_password();

				$check=$_POST['G_VOTER_ID'];	
				$star="UPDATE voter_table SET PASSWORD='$PASSWORD' where VOTER_ID='$check'";
					
				//echo "<br><br><br>into main code";

					 //successful execution of query;
					mysqli_query($con,$star);
					if(mysqli_affected_rows($con)>0)
					//$rows=mysqli_num_rows($result);
					//if($rows>0)
					{							
						echo '<br>YOUR PASSWORD: '.$PASSWORD;					
						header("refresh:10;url=fo_intermediate.php");

					}
				
				else
					{
						echo '<script>alert("not found")</script>';
						//echo '<br>not found pls....!!';
						header("refresh:1;url=fo_intermediate.php");		
					
					}
			
			
				*/

    //}?>
	<html>
	<head>
	<link rel="stylesheet" type="text/css" href="form_style.css">
		</head>
	<div >

	<form name="voter_for_password"  action="fo_intermediate.php" method="post">
		<tr><td><label style="position:absolute;top:44%;left:20%;" >Voter ID :</label> 
	        <td><input style="position:absolute;top:42%;left:30%;" type="tel" name="G_VOTER_ID"  value="<?php echo $_SESSION['G_VOTER_ID']?>" disabled/>   </tr>
	        <tr><label style="position:absolute;top:60%;left:20%;" >Password :</label> 
	        <input style="position:absolute;top:58%;left:30%;" type="text" value="<?php echo $_SESSION['PASSWORD']?>" disabled/></tr> 
	        <br>
	<button class="button button1"  type="submit" name="SUB" style="position:absolute;top:40%;right:30%;">Back</button>
	</form>
	</div>
	
	<body>
	</body>
	</html>
	