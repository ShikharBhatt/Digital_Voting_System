<html>
<body>
<?php
session_start();

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';

		$FO_ID=$_SESSION['FO_ID'];
		$TITLE=$_POST['TITLE'];
		//$VOTER_ID=//"UV".rand(2000,9999999999);
        $CONS_ID=$_SESSION['FCONSM_ID'];

        $TITLE=$_POST['TITLE'];
        $FNAME=$_POST['FNAME'];
		$MNAME=$_POST['MNAME'];
        $LNAME=$_POST['LNAME'];
        $SEX=$_POST['SEX'];
        $DOB=$_POST['DOB'];
        $AADHAAR=$_POST['AADHAAR'];
        $STREET_ADD=$_POST['STREET_ADD'];
        $DISTRICT=$_POST['DISTRICT'];
        $STATE=$_POST['STATE'];
        $PINCODE=$_POST['PINCODE'];
        $POB=$_POST['POB'];
        $EDU_LEVEL=$_POST['EDU_LEVEL'];
        $CASTE=$_POST['CASTE'];
        $RELIGION=$_POST['RELIGION'];
        $NATIVE_LANG=$_POST['NATIVE_LANG'];
        $INCOME=$_POST['INCOME'];
        $PHY_CHAL=$_POST['PHY_CHAL'];
        $OCCP=$_POST['OCCP'];
        $MOB_NO=$_POST['MOB_NO'];
        $EMAIL=$_POST['EMAIL'];

	//	$AADHAAR_PROOF=$_POST['AADHAAR_PROOF'];
   //     $PHOTO=$_FILES['PHOTO'];
    //    $RESIDENT_PROOF=$_POST['RESIDENT_PROOF'];
        //$FO_ID=$_POST['FO_ID'];
        //$POLL_ID=$_POST['POLL_ID'];
        //$STATUS=$_POST['STATUS'];
        $OSE=$_POST['OSE'];

        $P_VID=$_POST['P_VID'];

        $CITY=$_POST['CITY'];

        $PASS_NO=$_POST['PASS_NO'];
    echo $PASS_NO;
        $VISA_NO=$_POST['VISA_NO'];
echo $VISA_NO;

 $file = $_FILES['AADHAAR_PROOF'];    //receive the posted file
		
		$name = $file['name'];
		echo $name;
		$fileext = explode('.',$name);
		$afileext= strtolower(end($fileext));
		


$file1 = $_FILES['PHOTO'];    //receive the posted file
		
		$name1 = $file1['name'];
		echo $name1;
		$fileext1 = explode('.',$name1);
		$afileext1= strtolower(end($fileext1));

$file2 = $_FILES['RESIDENT_PROOF'];    //receive the posted file
		
		$name2 = $file2['name'];
		echo " ".$name2;
		$fileext2 = explode('.',$name2);
		$afileext2= strtolower(end($fileext2));
	

		$allowed = array('pdf','jpg');


if(in_array($afileext,$allowed) && in_array($afileext1,$allowed) && in_array($afileext2,$allowed))
	{	
			
	$content = addslashes(file_get_contents($_FILES['AADHAAR_PROOF']['tmp_name']));
   //$VOTER_ID = '000000000078';
	//echo $content;
     if(empty($P_VID))
    {   
    	echo $P_VID."in if"; 
	$query="insert into voter_table
	(        
         CONS_ID,
         TITLE,
         FNAME,
         MNAME,
         LNAME,
         SEX,
         DOB,
         AADHAAR,
		 STREET_ADD,
         DISTRICT,
         STATE,
         PINCODE,
         POB,
         EDU_LEVEL,
         CASTE,
         RELIGION,
         NATIVE_LANG,
         INCOME,
         PHY_CHAL,
         OCCP,
         MOB_NO,
         EMAIL,
       	VISA_NO,
		PASS_NO,
		AADHAAR_PROOF,
         FO_ID,
         OSE,        
         CITY 
    )
	
		values( 
											'$CONS_ID',
											'$TITLE',
											'$FNAME',
											'$MNAME',
											'$LNAME',
											'$SEX',
											'$DOB',
											'$AADHAAR',
											'$STREET_ADD',	
											'$DISTRICT',
											'$STATE',
											'$PINCODE',
											'$POB',
											'$EDU_LEVEL',
											'$CASTE',
											'$RELIGION',
											'$NATIVE_LANG',
											'$INCOME',
											'$PHY_CHAL',
											'$OCCP',
											'$MOB_NO',
											'$EMAIL',
											'$VISA_NO',
											'$PASS_NO',
											'$content',												
											'$FO_ID',
											'$OSE',	
											'$CITY' )";
		}
		else{
			echo "$P_VID"."in ELSE";
		$query="insert into voter_table
	(        
         CONS_ID,
         TITLE,
         FNAME,
         MNAME,
         LNAME,
         SEX,
         DOB,
         AADHAAR,
		 STREET_ADD,
         DISTRICT,
         STATE,
         PINCODE,
         POB,
         EDU_LEVEL,
         CASTE,
         RELIGION,
         NATIVE_LANG,
         INCOME,
         PHY_CHAL,
         OCCP,
         MOB_NO,
         EMAIL,
       	VISA_NO,
		PASS_NO,
		AADHAAR_PROOF,
		P_VID,
         FO_ID,
         OSE,        
         CITY 
    )
	
		values( 
											'$CONS_ID',
											'$TITLE',
											'$FNAME',
											'$MNAME',
											'$LNAME',
											'$SEX',
											'$DOB',
											'$AADHAAR',
											'$STREET_ADD',	
											'$DISTRICT',
											'$STATE',
											'$PINCODE',
											'$POB',
											'$EDU_LEVEL',
											'$CASTE',
											'$RELIGION',
											'$NATIVE_LANG',
											'$INCOME',
											'$PHY_CHAL',
											'$OCCP',
											'$MOB_NO',
											'$EMAIL',
											'$VISA_NO',
											'$PASS_NO',
											'$content',	
											'$P_VID',

													
											'$FO_ID',
											'$OSE',	
											'$CITY' )";

	
		}

											echo "name: ----".$FNAME;echo "<br>";
											echo "sex:  ----".$SEX;echo "<br>";
											echo "DOB ----".$DOB;echo "<br>";
											echo "CONS_ID----".$CONS_ID;echo "<br>";
											echo "TITLE----".$TITLE;echo "<br>";
											echo "FNAME----".$FNAME;echo "<br>";
											echo "MNAME----".$MNAME;echo "<br>";
											echo "LNAME----".$LNAME;echo "<br>";
											
											
											echo "AADHAAR----".$AADHAAR;echo "<br>";
											echo "STREET_ADD----".$STREET_ADD;echo "<br>";	
											echo "DISTRICT----".$DISTRICT;echo "<br>";
											echo "STATE----".$STATE;echo "<br>";
											echo "PINCODE----".$PINCODE;echo "<br>";
											echo "POB----".$POB;echo "<br>";
											echo "EDU_LEVEL----".$EDU_LEVEL;echo "<br>";
											echo "CASTE----".$CASTE;echo "<br>";
											echo "RELIGION----".$RELIGION;echo "<br>";
											echo "NATIVE_LANG----".$NATIVE_LANG;echo "<br>";
											echo "INCOME----".$INCOME;echo "<br>";
											echo "PHY_CHAL----".$PHY_CHAL;echo "<br>";
											echo "OCCP----".$OCCP;echo "<br>";
											echo "MOB_NO----".$MOB_NO;echo "<br>";
											echo "EMAIL----".$EMAIL;echo "<br>";
											
											echo "P_VID-----".$P_VID;echo"<br>";
											echo "FO_ID----".$FO_ID;echo "<br>";
											echo "OSE----".$OSE;echo "<br>";	
											echo "CITY----".$CITY;echo "<br>";
				
				if(!mysqli_query($con,$query))
				{
					echo "<h1>failed</h1>";
					 echo("Error description: " . mysqli_error($con));
					}
				else
				{ 
					echo "recorded";
					header("refresh:5; url=fo_intermediate.php");
				}
	
	}

else		
		{	echo "not expected file uploaded !!  not registered";
				header("refresh:4;Voter_form.php");
		}
?>
</html>
</body>
