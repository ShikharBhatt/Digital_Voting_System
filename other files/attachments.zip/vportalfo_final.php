<html>
<head>
 <title>Field Officer Login</title>
 <link rel="stylesheet" type="text/css" href="login_style.css"> 
</head>
<body background="flag.jpg" style="background-position: center; background-size:100%;">
<div class="login-page">
  <div class="form">
    <form class="login-form" name="vportalFO" action="vportalfo_verify.php" method="post">
      <input type="text" placeholder="Field Officer ID" name="ID" required/>
      <input type="password" placeholder="Password"  name="PASS" required/>
      <button type="submit">login</button>
    </form>
  </div>
</div>
</body>
</html>