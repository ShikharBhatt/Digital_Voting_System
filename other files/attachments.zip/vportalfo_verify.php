<html>

<body>

<?php


//session_name("fo_session");
session_start();

$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';
	
	$ID = $_POST['ID'];
	$PASS= $_POST['PASS'];
	echo $ID."asdfghjk"."<br>".$PASS;
	
	$star="select * from fo_table where FO_ID= '$ID' and PASSWORD= '$PASS' ";
	if($result=mysqli_query($con,$star))
	{		
		$row=mysqli_fetch_array($result);
		if($row['FO_ID']== $ID && $row['PASSWORD']==$PASS)
		{
			$_SESSION['FO_ID']=$ID;
			header("refresh:5;url=vportalvoter_final.php");
		}
		else 
		{	echo "wrong password/username";
			//session_destroy();
			header("refresh:2; url=vportalfo_final.php");
		}
		
	}
	else
		{	echo "use correct identifier";
			//session_destroy();
		  	header("refresh:2; url=vportalfo_final.php");
		}
	
		
	
		
?>

</html>
