<html>

<body>

<?php
//session_name("fo_session");
session_start();
//session_name("voter_session");
//session_start();
$con = mysqli_connect('localhost','root','6991');
if(!$con) echo 'cannot connect';
if(!mysqli_select_db($con,'dvs'))
	echo 'cannot connect';
	
	$VID = $_POST['V_ID'];
	$VPASS= $_POST['V_PASS'];
	echo $VID."asdfghjk"."<br>".$VPASS;
	$star="select *,TIMESTAMPDIFF(YEAR,DOB,CURDATE()) AS AGE from voter_table where VOTER_ID= '$VID' ";
	if($result=mysqli_query($con,$star))
	{		
		$row=mysqli_fetch_array($result);
		if($row['VOTER_ID']== $VID )
		{
			$_SESSION['VOTER_ID'] = $VID;
			$_SESSION['AGE'] = $row['AGE'];
			echo "in our destination";
			echo $row['VOTER_ID'];
			if($row['AGE']>60)
			{
				header("refresh:2;url=timer_old.php");
			}
			else
			{
				header("refresh:2;url=timer.php");
			}
		}
		else 
		{	
			echo "wrong password/username";
			//session_name("voter_session");
			//session_destroy();
			echo $_SESSION['VOTER_ID'];
			echo $_SESSION['FO_ID'];
			header("refresh:10; url=vportalvoter_final.php");
		}
		
	}
	else
		{	
			echo "use correct identifier";
			///session_name("voter_session");
			session_destroy();
		 	header("refresh:10; url=vportalvoter_final.php");
		}
	
		
	
		
?>

</html>

</body>